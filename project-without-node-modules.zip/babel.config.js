module.exports = {
    plugins: [['@babel/plugin-proposal-decorators', { legacy: true }]],
}